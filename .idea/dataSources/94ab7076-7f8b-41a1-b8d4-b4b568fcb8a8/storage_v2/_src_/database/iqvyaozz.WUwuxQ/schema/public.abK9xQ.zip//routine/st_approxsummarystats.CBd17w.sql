create function st_approxsummarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean) returns summarystats
    stable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_summarystats($1, $2, 1, $3, 0.1)
$$;

alter function st_approxsummarystats(text, text, boolean) owner to postgres;

