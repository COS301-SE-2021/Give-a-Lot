create function st_asgml(version integer, geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0, nprefix text DEFAULT NULL::text, id text DEFAULT NULL::text) returns text
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_AsGML($1, $2, $3, $4, $5, $6);
$$;

comment on function st_asgml(integer, geography, integer, integer, text, text) is 'args: version, geog, maxdecimaldigits=15, options=0, nprefix=null, id=null - Return the geometry as a GML version 2 or 3 element.';

alter function st_asgml(integer, geography, integer, integer, text, text) owner to postgres;

