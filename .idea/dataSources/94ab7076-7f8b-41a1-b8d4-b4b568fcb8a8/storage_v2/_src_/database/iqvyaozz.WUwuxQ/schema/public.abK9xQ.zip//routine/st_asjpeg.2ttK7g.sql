create function st_asjpeg(rast raster, nbands integer[], quality integer) returns bytea
    immutable
    strict
    parallel safe
    language plpgsql
as
$$
DECLARE
		quality2 int;
		options text[];
	BEGIN
		IF quality IS NOT NULL THEN
			IF quality > 100 THEN
				quality2 := 100;
			ELSEIF quality < 10 THEN
				quality2 := 10;
			ELSE
				quality2 := quality;
			END IF;

			options := array_append(options, 'QUALITY=' || quality2);
		END IF;

		RETURN public.st_asjpeg(st_band($1, $2), options);
	END;

$$;

comment on function st_asjpeg(raster, integer[], integer) is 'args: rast, nbands, quality - Return the raster tile selected bands as a single Joint Photographic Exports Group (JPEG) image (byte array). If no band is specified and 1 or more than 3 bands, then only the first band is used. If only 3 bands then all 3 bands are used and mapped to RGB.';

alter function st_asjpeg(raster, integer[], integer) owner to postgres;

