create function updaterastersrid(table_name name, column_name name, new_srid integer) returns boolean
    strict
    language sql
as
$$
SELECT  public._UpdateRasterSRID('', $1, $2, $3)
$$;

comment on function updaterastersrid(name, name, integer) is 'args: table_name, column_name, new_srid - Change the SRID of all rasters in the user-specified column and table.';

alter function updaterastersrid(name, name, integer) owner to postgres;

