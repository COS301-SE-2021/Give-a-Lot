create function st_approxcount(rastertable text, rastercolumn text, exclude_nodata_value boolean, sample_percent double precision DEFAULT 0.1) returns bigint
    stable
    strict
    language sql
as
$$
SELECT public._ST_count($1, $2, 1, $3, $4)
$$;

alter function st_approxcount(text, text, boolean, double precision) owner to postgres;

